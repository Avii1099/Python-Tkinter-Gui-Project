

1.AGE CALCULATOR(AGE CALCULATOR.py):

I have made this age calculator app using basic widgets such as Labels, Buttons, Entry fields with a little bit of logic. Have a look at the output.

Briefing the steps to create age calculator are:

1.Importing the module – tkinter

2.Create the main window (container)

3.Add any number of widgets to the main window.

4.Apply the event Trigger on the widgets.



